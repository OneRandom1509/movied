# Movied

A movie database management system with a REST API (FastAPI + MongoDB) and a dashboard frontend.

## Setup

```bash
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
```

Make sure MongoDB is running on `localhost:27017`, then:

```bash
python seed_db.py      # optional sample data
uvicorn app.main:app --reload
```

Open `http://localhost:8000` for the dashboard, `/docs` for the API docs.
