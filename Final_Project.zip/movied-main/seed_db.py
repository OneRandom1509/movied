import asyncio
from motor.motor_asyncio import AsyncIOMotorClient
from datetime import datetime, timedelta
from bson import ObjectId

MONGO_URI = "mongodb://localhost:27017"
DB_NAME = "movie_db"

async def seed():
    print("Connecting to MongoDB...")
    client = AsyncIOMotorClient(MONGO_URI)
    db = client[DB_NAME]
    
    # 1. Clean existing database collections
    print("Cleaning existing database...")
    await db.directors.delete_many({})
    await db.genres.delete_many({})
    await db.actors.delete_many({})
    await db.movies.delete_many({})
    await db.reviews.delete_many({})
    
    # 2. Insert Genres
    print("Seeding Genres...")
    genres = [
        {"name": "Sci-Fi"},
        {"name": "Action"},
        {"name": "Drama"},
        {"name": "Thriller"},
        {"name": "Biography"}
    ]
    genre_docs = []
    for g in genres:
        res = await db.genres.insert_one(g)
        genre_docs.append({"id": res.inserted_id, "name": g["name"]})
    
    # Map for easy lookup
    g_map = {g["name"]: g["id"] for g in genre_docs}
    
    # 3. Insert Directors
    print("Seeding Directors...")
    directors = [
        {"name": "Christopher Nolan", "birth_year": 1970, "nationality": "British-American"},
        {"name": "Denis Villeneuve", "birth_year": 1967, "nationality": "Canadian"},
        {"name": "Quentin Tarantino", "birth_year": 1963, "nationality": "American"}
    ]
    director_docs = []
    for d in directors:
        res = await db.directors.insert_one(d)
        director_docs.append({"id": res.inserted_id, "name": d["name"]})
        
    d_map = {d["name"]: d["id"] for d in director_docs}
    
    # 4. Insert Actors
    print("Seeding Actors...")
    actors = [
        {"name": "Leonardo DiCaprio", "birth_year": 1974, "nationality": "American"},
        {"name": "Cillian Murphy", "birth_year": 1976, "nationality": "Irish"},
        {"name": "Timothée Chalamet", "birth_year": 1995, "nationality": "American-French"},
        {"name": "Florence Pugh", "birth_year": 1996, "nationality": "British"},
        {"name": "Joseph Gordon-Levitt", "birth_year": 1981, "nationality": "American"},
        {"name": "Tom Hardy", "birth_year": 1977, "nationality": "British"}
    ]
    actor_docs = []
    for a in actors:
        res = await db.actors.insert_one(a)
        actor_docs.append({"id": res.inserted_id, "name": a["name"]})
        
    a_map = {a["name"]: a["id"] for a in actor_docs}
    
    # 5. Insert Movies with Relationships
    print("Seeding Movies...")
    movies = [
        {
            "title": "Inception",
            "release_year": 2010,
            "duration": 148,
            "language": "English",
            "rating": 0.0,
            "box_office": 836.8,
            "director_id": d_map["Christopher Nolan"],
            "genre_id": g_map["Sci-Fi"],
            "actor_ids": [a_map["Leonardo DiCaprio"], a_map["Joseph Gordon-Levitt"], a_map["Tom Hardy"], a_map["Cillian Murphy"]]
        },
        {
            "title": "Oppenheimer",
            "release_year": 2023,
            "duration": 180,
            "language": "English",
            "rating": 0.0,
            "box_office": 957.0,
            "director_id": d_map["Christopher Nolan"],
            "genre_id": g_map["Biography"],
            "actor_ids": [a_map["Cillian Murphy"], a_map["Florence Pugh"]]
        },
        {
            "title": "Dune: Part Two",
            "release_year": 2024,
            "duration": 166,
            "language": "English",
            "rating": 0.0,
            "box_office": 712.4,
            "director_id": d_map["Denis Villeneuve"],
            "genre_id": g_map["Sci-Fi"],
            "actor_ids": [a_map["Timothée Chalamet"], a_map["Florence Pugh"]]
        },
        {
            "title": "Interstellar",
            "release_year": 2014,
            "duration": 169,
            "language": "English",
            "rating": 0.0,
            "box_office": 731.0,
            "director_id": d_map["Christopher Nolan"],
            "genre_id": g_map["Sci-Fi"],
            "actor_ids": [a_map["Timothée Chalamet"]] # Timothee has a minor role as young Tom
        }
    ]
    
    movie_docs = []
    for m in movies:
        res = await db.movies.insert_one(m)
        movie_docs.append({"id": res.inserted_id, "title": m["title"]})
        
    m_map = {m["title"]: m["id"] for m in movie_docs}
    
    # 6. Insert Reviews
    print("Seeding Reviews...")
    reviews = [
        # Inception reviews
        {
            "movie_id": m_map["Inception"],
            "reviewer_name": "Alice Smith",
            "rating": 9.5,
            "review_text": "Mind-bending masterpiece! The cinematography and Hans Zimmer score are legendary.",
            "created_at": datetime.utcnow() - timedelta(days=100)
        },
        {
            "movie_id": m_map["Inception"],
            "reviewer_name": "Bob Jones",
            "rating": 8.8,
            "review_text": "Brilliant concept, though the rules get a bit convoluted on first watch. Excellent acting.",
            "created_at": datetime.utcnow() - timedelta(days=90)
        },
        # Oppenheimer reviews
        {
            "movie_id": m_map["Oppenheimer"],
            "reviewer_name": "Charlie Brown",
            "rating": 9.2,
            "review_text": "Cillian Murphy gives the performance of a lifetime. The sound design is chilling.",
            "created_at": datetime.utcnow() - timedelta(days=30)
        },
        {
            "movie_id": m_map["Oppenheimer"],
            "reviewer_name": "Diana Prince",
            "rating": 9.0,
            "review_text": "A technical triumph. Visual storytelling is peak Christopher Nolan.",
            "created_at": datetime.utcnow() - timedelta(days=25)
        },
        # Dune reviews
        {
            "movie_id": m_map["Dune: Part Two"],
            "reviewer_name": "Evan Wright",
            "rating": 9.6,
            "review_text": "The scale and grandeur of this movie is unmatched. Best sci-fi in a decade.",
            "created_at": datetime.utcnow() - timedelta(days=10)
        },
        {
            "movie_id": m_map["Dune: Part Two"],
            "reviewer_name": "Fiona Gallagher",
            "rating": 8.5,
            "review_text": "Stunning visuals and great soundtrack, but pacing felt slightly rushed in the second half.",
            "created_at": datetime.utcnow() - timedelta(days=5)
        },
        # Interstellar reviews
        {
            "movie_id": m_map["Interstellar"],
            "reviewer_name": "George Lucas",
            "rating": 8.9,
            "review_text": "Beautiful portrayal of space travel and love transcending dimensions.",
            "created_at": datetime.utcnow() - timedelta(days=50)
        }
    ]
    
    for r in reviews:
        await db.reviews.insert_one(r)
        
    # 7. Recalculate movie average ratings
    print("Updating movie average ratings...")
    for movie_title, movie_id in m_map.items():
        pipeline = [
            {"$match": {"movie_id": movie_id}},
            {"$group": {"_id": "$movie_id", "avg_rating": {"$avg": "$rating"}}}
        ]
        cursor = db.reviews.aggregate(pipeline)
        result = await cursor.to_list(length=1)
        if result:
            avg_rating = round(result[0]["avg_rating"], 1)
            await db.movies.update_one({"_id": movie_id}, {"$set": {"rating": avg_rating}})
            print(f"Updated {movie_title} average rating to {avg_rating}")

    client.close()
    print("Database seeding completed successfully!")

if __name__ == "__main__":
    asyncio.run(seed())
