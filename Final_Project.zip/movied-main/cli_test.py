import urllib.request
import urllib.error
import json
import time

BASE_URL = "http://127.0.0.1:8000"

# Colors for terminal styling
class Colors:
    HEADER = '\033[95m'
    BLUE = '\033[94m'
    CYAN = '\033[96m'
    GREEN = '\033[92m'
    WARNING = '\033[93m'
    FAIL = '\033[91m'
    ENDC = '\033[0m'
    BOLD = '\033[1m'
    UNDERLINE = '\033[4m'

def print_header(title):
    print(f"\n{Colors.BOLD}{Colors.HEADER}{'=' * 60}{Colors.ENDC}")
    print(f"{Colors.BOLD}{Colors.HEADER}  {title}{Colors.ENDC}")
    print(f"{Colors.BOLD}{Colors.HEADER}{'=' * 60}{Colors.ENDC}\n")

def print_sub(title):
    print(f"\n{Colors.BOLD}{Colors.BLUE}>>> {title}{Colors.ENDC}")

def print_json(data):
    print(f"{Colors.CYAN}{json.dumps(data, indent=2)}{Colors.ENDC}")

def api_call(path, method="GET", data=None):
    url = f"{BASE_URL}{path}"
    req = urllib.request.Request(url, method=method)
    req.add_header("Content-Type", "application/json")
    
    if data is not None:
        req.data = json.dumps(data).encode("utf-8")
        
    try:
        with urllib.request.urlopen(req) as response:
            res_body = response.read().decode("utf-8")
            if res_body:
                return json.loads(res_body)
            return {"message": "Success (No Content)"}
    except urllib.error.HTTPError as e:
        err_body = e.read().decode("utf-8")
        print(f"{Colors.FAIL}API Error {e.code}: {err_body}{Colors.ENDC}")
        try:
            return json.loads(err_body)
        except:
            return {"detail": err_body}
    except Exception as e:
        print(f"{Colors.FAIL}Connection Error: {e}{Colors.ENDC}")
        return {"detail": str(e)}

def run_tests():
    print_header("Movied CLI Operations Runner")
    print(f"Backend Server: {Colors.BOLD}{BASE_URL}{Colors.ENDC}")
    
    # 1. Status Check
    print_sub("Checking Backend API Health Status")
    res = api_call("/")
    print_json(res)
    if "status" not in res or res["status"] != "healthy":
        print(f"{Colors.FAIL}Backend is not active. Make sure uvicorn is running!{Colors.ENDC}")
        return

    # 2. SEED THE DATABASE
    print_sub("Seeding Database with sample records using seed_db.py logic")
    # For simplicity, we assume seed_db.py has run, but let's query the summary statistics to verify
    stats = api_call("/api/reports/summary-stats")
    print("Initial Database stats:")
    print_json(stats)
    
    # Let's perform standard CRUD operations on Genres
    print_header("1. GENRES CRUD OPERATIONS")
    
    print_sub("CREATE: Adding a new genre 'Fantasy'")
    new_genre = api_call("/api/genres/", "POST", {"name": "Fantasy"})
    print_json(new_genre)
    genre_id = new_genre["id"]
    
    print_sub("READ: Fetching all genres")
    genres = api_call("/api/genres/")
    print(f"Total genres available: {len(genres)}")
    
    print_sub("UPDATE: Modifying genre name to 'Epic Fantasy'")
    updated_genre = api_call(f"/api/genres/{genre_id}", "PUT", {"name": "Epic Fantasy"})
    print_json(updated_genre)
    
    print_sub("DELETE: Removing the 'Epic Fantasy' genre")
    del_res = api_call(f"/api/genres/{genre_id}", "DELETE")
    print_json(del_res)

    # CRUD on Directors
    print_header("2. DIRECTORS CRUD OPERATIONS")
    
    print_sub("CREATE: Adding a new director 'Martin Scorsese'")
    new_director = api_call("/api/directors/", "POST", {
        "name": "Martin Scorsese", 
        "birth_year": 1942, 
        "nationality": "American"
    })
    print_json(new_director)
    director_id = new_director["id"]
    
    print_sub("READ: Fetching director info")
    director = api_call(f"/api/directors/{director_id}")
    print_json(director)
    
    print_sub("UPDATE: Modifying director's birth year")
    updated_dir = api_call(f"/api/directors/{director_id}", "PUT", {
        "name": "Martin Scorsese",
        "birth_year": 1943,
        "nationality": "American"
    })
    print_json(updated_dir)
    
    print_sub("DELETE: Removing 'Martin Scorsese' from database")
    del_dir = api_call(f"/api/directors/{director_id}", "DELETE")
    print_json(del_dir)

    # CRUD on Actors
    print_header("3. ACTORS CRUD OPERATIONS")
    
    print_sub("CREATE: Adding a new actor 'Robert De Niro'")
    new_actor = api_call("/api/actors/", "POST", {
        "name": "Robert De Niro",
        "birth_year": 1943,
        "nationality": "American"
    })
    print_json(new_actor)
    actor_id = new_actor["id"]
    
    print_sub("READ: Fetching actor profile")
    actor = api_call(f"/api/actors/{actor_id}")
    print_json(actor)
    
    print_sub("UPDATE: Updating actor nationality")
    updated_act = api_call(f"/api/actors/{actor_id}", "PUT", {
        "name": "Robert De Niro",
        "birth_year": 1943,
        "nationality": "American-Italian"
    })
    print_json(updated_act)
    
    print_sub("DELETE: Removing actor from database")
    del_act = api_call(f"/api/actors/{actor_id}", "DELETE")
    print_json(del_act)

    # CRUD on Movies
    print_header("4. MOVIES CRUD OPERATIONS")
    
    # To create a movie, we need an active genre and director ID. Let's get the seeded ones:
    genres_list = api_call("/api/genres/")
    directors_list = api_call("/api/directors/")
    actors_list = api_call("/api/actors/")
    
    sci_fi_id = [g["id"] for g in genres_list if g["name"] == "Sci-Fi"][0]
    nolan_id = [d["id"] for d in directors_list if d["name"] == "Christopher Nolan"][0]
    murphy_id = [a["id"] for a in actors_list if a["name"] == "Cillian Murphy"][0]
    pugh_id = [a["id"] for a in actors_list if a["name"] == "Florence Pugh"][0]
    
    print_sub("CREATE: Creating a new movie 'Memento'")
    new_movie = api_call("/api/movies/", "POST", {
        "title": "Memento",
        "release_year": 2000,
        "duration": 113,
        "language": "English",
        "rating": 0.0,
        "box_office": 40.0,
        "director_id": nolan_id,
        "genre_id": sci_fi_id,
        "actor_ids": [murphy_id] # Cillian Murphy isn't in Memento, but for testing references
    })
    print_json(new_movie)
    movie_id = new_movie["id"]
    
    print_sub("READ: Fetching standard movie schema")
    movie = api_call(f"/api/movies/{movie_id}")
    print_json(movie)
    
    print_sub("READ DETAILED: Resolving relationships (Director, Genre, Cast, Reviews) via aggregate lookup")
    movie_detailed = api_call(f"/api/movies/{movie_id}/detailed")
    print_json(movie_detailed)
    
    print_sub("UPDATE: Modifying movie rating and cast list (adding Florence Pugh)")
    updated_movie = api_call(f"/api/movies/{movie_id}", "PUT", {
        "title": "Memento",
        "release_year": 2000,
        "duration": 113,
        "language": "English",
        "box_office": 40.0,
        "director_id": nolan_id,
        "genre_id": sci_fi_id,
        "actor_ids": [murphy_id, pugh_id]
    })
    print_json(updated_movie)

    # CRUD on Reviews
    print_header("5. REVIEWS CRUD & RATING RECALCULATION")
    
    print_sub("CREATE: Adding review for 'Memento' (Score: 8.5)")
    rev_1 = api_call("/api/reviews/", "POST", {
        "movie_id": movie_id,
        "reviewer_name": "John Doe",
        "rating": 8.5,
        "review_text": "Incredible backwards-structured plot! Keeps you guessing."
    })
    print_json(rev_1)
    
    print_sub("CREATE: Adding second review for 'Memento' (Score: 9.5)")
    rev_2 = api_call("/api/reviews/", "POST", {
        "movie_id": movie_id,
        "reviewer_name": "Jane Miller",
        "rating": 9.5,
        "review_text": "One of Nolan's finest works. Unforgettable."
    })
    print_json(rev_2)
    
    print_sub("VERIFY RECALCULATION: Check if movie rating has been recalculated (Avg: 9.0)")
    movie_checked = api_call(f"/api/movies/{movie_id}")
    print(f"Stored movie rating: {Colors.WARNING}{movie_checked['rating']}{Colors.ENDC}")
    print_json(movie_checked)
    
    print_sub("DELETE: Cleaning up reviews and movie 'Memento'")
    # Deleting the movie will cascade delete the reviews in our database layer
    del_mov = api_call(f"/api/movies/{movie_id}", "DELETE")
    print_json(del_mov)

    # MongoDB Aggregations Reports
    print_header("6. ADVANCED MONGO_DB AGGREGATION PIPELINES (REPORTS)")
    
    print_sub("REPORT 1: Top-Rated Movies (Dynamic Average of User Reviews)")
    rep_top = api_call("/api/reports/top-rated")
    print_json(rep_top)
    
    print_sub("REPORT 2: Movies Grouped by Genre")
    rep_genre = api_call("/api/reports/movies-by-genre")
    print_json(rep_genre)
    
    print_sub("REPORT 3: Movies Grouped by Director")
    rep_director = api_call("/api/reports/movies-by-director")
    print_json(rep_director)
    
    print_sub("REPORT 4: Prolific Actors (Appearing in Multiple Movies)")
    rep_actors = api_call("/api/reports/prolific-actors")
    print_json(rep_actors)
    
    print_sub("REPORT 5: Overall Database Summary Stats")
    rep_stats = api_call("/api/reports/summary-stats")
    print_json(rep_stats)
    
    print_header("CLI TESTS COMPLETED SUCCESSFULLY!")

if __name__ == "__main__":
    run_tests()
