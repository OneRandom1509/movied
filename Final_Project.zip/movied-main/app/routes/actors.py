from fastapi import APIRouter, HTTPException, Depends
from typing import List
from app.models import ActorCreate, ActorResponse
from app.database import get_db
import app.crud as crud

router = APIRouter(prefix="/api/actors", tags=["Actors"])

@router.post("/", response_model=ActorResponse)
async def create_actor(actor: ActorCreate, db=Depends(get_db)):
    res = await crud.create_actor(db, actor.model_dump())
    return res

@router.get("/", response_model=List[ActorResponse])
async def list_actors(db=Depends(get_db)):
    return await crud.get_actors(db)

@router.get("/{actor_id}", response_model=ActorResponse)
async def get_actor(actor_id: str, db=Depends(get_db)):
    res = await crud.get_actor(db, actor_id)
    if not res:
        raise HTTPException(status_code=404, detail="Actor not found")
    return res

@router.put("/{actor_id}", response_model=ActorResponse)
async def update_actor(actor_id: str, actor: ActorCreate, db=Depends(get_db)):
    res = await crud.update_actor(db, actor_id, actor.model_dump())
    if not res:
        raise HTTPException(status_code=404, detail="Actor not found")
    return res

@router.delete("/{actor_id}")
async def delete_actor(actor_id: str, db=Depends(get_db)):
    success = await crud.delete_actor(db, actor_id)
    if not success:
        raise HTTPException(status_code=404, detail="Actor not found or could not be deleted")
    return {"message": "Actor deleted successfully"}
