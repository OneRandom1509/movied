from fastapi import APIRouter, HTTPException, Depends
from typing import List
from app.models import MovieCreate, MovieResponse, MovieDetailResponse
from app.database import get_db
import app.crud as crud

router = APIRouter(prefix="/api/movies", tags=["Movies"])

@router.post("/", response_model=MovieResponse)
async def create_movie(movie: MovieCreate, db=Depends(get_db)):
    res = await crud.create_movie(db, movie.model_dump())
    return res

@router.get("/", response_model=List[MovieResponse])
async def list_movies(db=Depends(get_db)):
    return await crud.get_movies(db)

@router.get("/detailed", response_model=List[MovieDetailResponse])
async def list_movies_detailed(db=Depends(get_db)):
    return await crud.get_movies_detailed(db)

@router.get("/{movie_id}", response_model=MovieResponse)
async def get_movie(movie_id: str, db=Depends(get_db)):
    res = await crud.get_movie(db, movie_id)
    if not res:
        raise HTTPException(status_code=404, detail="Movie not found")
    return res

@router.get("/{movie_id}/detailed", response_model=MovieDetailResponse)
async def get_movie_detailed(movie_id: str, db=Depends(get_db)):
    res = await crud.get_movie_detailed(db, movie_id)
    if not res:
        raise HTTPException(status_code=404, detail="Movie details not found")
    return res

@router.put("/{movie_id}", response_model=MovieResponse)
async def update_movie(movie_id: str, movie: MovieCreate, db=Depends(get_db)):
    res = await crud.update_movie(db, movie_id, movie.model_dump())
    if not res:
        raise HTTPException(status_code=404, detail="Movie not found")
    return res

@router.delete("/{movie_id}")
async def delete_movie(movie_id: str, db=Depends(get_db)):
    success = await crud.delete_movie(db, movie_id)
    if not success:
        raise HTTPException(status_code=404, detail="Movie not found or could not be deleted")
    return {"message": "Movie deleted successfully"}
