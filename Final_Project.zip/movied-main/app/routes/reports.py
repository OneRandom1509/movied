from fastapi import APIRouter, Depends, Query
from typing import List, Dict, Any, Optional
from app.database import get_db
from app.crud import serialize_docs, serialize_doc
from bson import ObjectId

router = APIRouter(prefix="/api/reports", tags=["Reports"])

@router.get("/top-rated")
async def get_top_rated_movies(limit: int = Query(10, ge=1)):
    """
    Returns top-rated movies based on their average user reviews,
    falling back to the movie's default rating if no reviews exist.
    """
    db = get_db()
    pipeline = [
        {
            "$lookup": {
                "from": "reviews",
                "localField": "_id",
                "foreignField": "movie_id",
                "as": "movie_reviews"
            }
        },
        {
            "$project": {
                "title": 1,
                "release_year": 1,
                "duration": 1,
                "language": 1,
                "box_office": 1,
                "stored_rating": "$rating",
                "average_rating": {
                    "$cond": {
                        "if": {"$gt": [{"$size": "$movie_reviews"}, 0]},
                        "then": {"$round": [{"$avg": "$movie_reviews.rating"}, 2]},
                        "else": "$rating"
                    }
                },
                "review_count": {"$size": "$movie_reviews"}
            }
        },
        {"$sort": {"average_rating": -1, "review_count": -1, "title": 1}},
        {"$limit": limit}
    ]
    cursor = db.movies.aggregate(pipeline)
    docs = await cursor.to_list(length=limit)
    return serialize_docs(docs)

@router.get("/movies-by-genre")
async def get_movies_by_genre():
    """
    Groups and lists movies under their respective genres.
    """
    db = get_db()
    pipeline = [
        {
            "$lookup": {
                "from": "genres",
                "localField": "genre_id",
                "foreignField": "_id",
                "as": "genre_details"
            }
        },
        {"$unwind": {"path": "$genre_details", "preserveNullAndEmptyArrays": True}},
        {
            "$group": {
                "_id": "$genre_details.name",
                "genre_id": {"$first": {"$toString": "$genre_details._id"}},
                "movies": {
                    "$push": {
                        "id": {"$toString": "$_id"},
                        "title": "$title",
                        "release_year": "$release_year",
                        "rating": "$rating",
                        "box_office": "$box_office"
                    }
                },
                "movie_count": {"$sum": 1}
            }
        },
        {
            "$project": {
                "_id": 0,
                "genre": {"$ifNull": ["$_id", "Uncategorized"]},
                "genre_id": 1,
                "movies": 1,
                "movie_count": 1
            }
        },
        {"$sort": {"genre": 1}}
    ]
    cursor = db.movies.aggregate(pipeline)
    docs = await cursor.to_list(length=1000)
    return serialize_docs(docs)

@router.get("/movies-by-director")
async def get_movies_by_director(director_id: Optional[str] = None):
    """
    Retrieves movies grouped by directors. Can be filtered by a specific director_id.
    """
    db = get_db()
    
    match_stage = {}
    if director_id and ObjectId.is_valid(director_id):
        match_stage = {"_id": ObjectId(director_id)}
        
    pipeline = []
    if match_stage:
        pipeline.append({"$match": match_stage})
        
    pipeline.extend([
        {
            "$lookup": {
                "from": "movies",
                "localField": "_id",
                "foreignField": "director_id",
                "as": "director_movies"
            }
        },
        {
            "$project": {
                "director_id": {"$toString": "$_id"},
                "name": 1,
                "birth_year": 1,
                "nationality": 1,
                "movies": {
                    "$map": {
                        "input": "$director_movies",
                        "as": "m",
                        "in": {
                            "id": {"$toString": "$$m._id"},
                            "title": "$$m.title",
                            "release_year": "$$m.release_year",
                            "rating": "$$m.rating",
                            "box_office": "$$m.box_office"
                        }
                    }
                },
                "movie_count": {"$size": "$director_movies"}
            }
        },
        {"$sort": {"name": 1}}
    ])
    
    cursor = db.directors.aggregate(pipeline)
    docs = await cursor.to_list(length=1000)
    return serialize_docs(docs)

@router.get("/prolific-actors")
async def get_prolific_actors():
    """
    Retrieves actors who appear in multiple movies (movie_count > 1).
    """
    db = get_db()
    pipeline = [
        {"$unwind": "$actor_ids"},
        {
            "$group": {
                "_id": "$actor_ids",
                "movie_ids": {"$push": {"$toString": "$_id"}},
                "movie_titles": {"$push": "$title"},
                "movie_count": {"$sum": 1}
            }
        },
        {"$match": {"movie_count": {"$gt": 1}}},
        {
            "$lookup": {
                "from": "actors",
                "localField": "_id",
                "foreignField": "_id",
                "as": "actor_details"
            }
        },
        {"$unwind": "$actor_details"},
        {
            "$project": {
                "_id": 0,
                "actor_id": {"$toString": "$_id"},
                "name": "$actor_details.name",
                "birth_year": "$actor_details.birth_year",
                "nationality": "$actor_details.nationality",
                "movie_count": 1,
                "movies": "$movie_titles"
            }
        },
        {"$sort": {"movie_count": -1, "name": 1}}
    ]
    cursor = db.movies.aggregate(pipeline)
    docs = await cursor.to_list(length=1000)
    return serialize_docs(docs)

@router.get("/summary-stats")
async def get_summary_stats():
    """
    Returns general database statistics including movie averages, review averages,
    and collection document counts.
    """
    db = get_db()
    
    # Simple counts
    total_movies = await db.movies.count_documents({})
    total_reviews = await db.reviews.count_documents({})
    total_actors = await db.actors.count_documents({})
    total_directors = await db.directors.count_documents({})
    total_genres = await db.genres.count_documents({})
    
    # Aggregation for averages
    avg_pipeline = [
        {
            "$group": {
                "_id": None,
                "avg_movie_rating": {"$avg": "$rating"},
                "avg_box_office": {"$avg": "$box_office"},
                "total_box_office": {"$sum": "$box_office"}
            }
        }
    ]
    
    avg_cursor = db.movies.aggregate(avg_pipeline)
    avg_results = await avg_cursor.to_list(length=1)
    
    avg_movie_rating = 0.0
    avg_box_office = 0.0
    total_box_office = 0.0
    
    if avg_results:
        avg_movie_rating = round(avg_results[0].get("avg_movie_rating", 0.0) or 0.0, 2)
        avg_box_office = round(avg_results[0].get("avg_box_office", 0.0) or 0.0, 2)
        total_box_office = round(avg_results[0].get("total_box_office", 0.0) or 0.0, 2)
        
    avg_review_pipeline = [
        {
            "$group": {
                "_id": None,
                "avg_review_rating": {"$avg": "$rating"}
            }
        }
    ]
    
    avg_rev_cursor = db.reviews.aggregate(avg_review_pipeline)
    avg_rev_results = await avg_rev_cursor.to_list(length=1)
    avg_review_rating = 0.0
    if avg_rev_results:
        avg_review_rating = round(avg_rev_results[0].get("avg_review_rating", 0.0) or 0.0, 2)
        
    return {
        "counts": {
            "movies": total_movies,
            "reviews": total_reviews,
            "actors": total_actors,
            "directors": total_directors,
            "genres": total_genres
        },
        "averages": {
            "movie_rating": avg_movie_rating,
            "review_rating": avg_review_rating,
            "box_office_millions": avg_box_office,
            "total_box_office_millions": total_box_office
        }
    }
