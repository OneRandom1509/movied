from fastapi import APIRouter, HTTPException, Depends
from typing import List
from app.models import ReviewCreate, ReviewResponse
from app.database import get_db
import app.crud as crud

router = APIRouter(prefix="/api/reviews", tags=["Reviews"])

@router.post("/", response_model=ReviewResponse)
async def create_review(review: ReviewCreate, db=Depends(get_db)):
    # Verify movie exists
    movie = await crud.get_movie(db, review.movie_id)
    if not movie:
        raise HTTPException(status_code=400, detail="Cannot review a non-existent movie")
    res = await crud.create_review(db, review.model_dump())
    return res

@router.get("/", response_model=List[ReviewResponse])
async def list_reviews(db=Depends(get_db)):
    return await crud.get_reviews(db)

@router.get("/{review_id}", response_model=ReviewResponse)
async def get_review(review_id: str, db=Depends(get_db)):
    res = await crud.get_review(db, review_id)
    if not res:
        raise HTTPException(status_code=404, detail="Review not found")
    return res

@router.put("/{review_id}", response_model=ReviewResponse)
async def update_review(review_id: str, review: ReviewCreate, db=Depends(get_db)):
    res = await crud.update_review(db, review_id, review.model_dump())
    if not res:
        raise HTTPException(status_code=404, detail="Review not found")
    return res

@router.delete("/{review_id}")
async def delete_review(review_id: str, db=Depends(get_db)):
    success = await crud.delete_review(db, review_id)
    if not success:
        raise HTTPException(status_code=404, detail="Review not found or could not be deleted")
    return {"message": "Review deleted successfully"}
