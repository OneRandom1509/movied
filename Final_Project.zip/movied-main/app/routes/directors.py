from fastapi import APIRouter, HTTPException, Depends
from typing import List
from app.models import DirectorCreate, DirectorResponse
from app.database import get_db
import app.crud as crud

router = APIRouter(prefix="/api/directors", tags=["Directors"])

@router.post("/", response_model=DirectorResponse)
async def create_director(director: DirectorCreate, db=Depends(get_db)):
    res = await crud.create_director(db, director.model_dump())
    return res

@router.get("/", response_model=List[DirectorResponse])
async def list_directors(db=Depends(get_db)):
    return await crud.get_directors(db)

@router.get("/{director_id}", response_model=DirectorResponse)
async def get_director(director_id: str, db=Depends(get_db)):
    res = await crud.get_director(db, director_id)
    if not res:
        raise HTTPException(status_code=404, detail="Director not found")
    return res

@router.put("/{director_id}", response_model=DirectorResponse)
async def update_director(director_id: str, director: DirectorCreate, db=Depends(get_db)):
    res = await crud.update_director(db, director_id, director.model_dump())
    if not res:
        raise HTTPException(status_code=404, detail="Director not found")
    return res

@router.delete("/{director_id}")
async def delete_director(director_id: str, db=Depends(get_db)):
    success = await crud.delete_director(db, director_id)
    if not success:
        raise HTTPException(status_code=404, detail="Director not found or could not be deleted")
    return {"message": "Director deleted successfully"}
