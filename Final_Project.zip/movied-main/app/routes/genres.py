from fastapi import APIRouter, HTTPException, Depends
from typing import List
from app.models import GenreCreate, GenreResponse
from app.database import get_db
import app.crud as crud

router = APIRouter(prefix="/api/genres", tags=["Genres"])

@router.post("/", response_model=GenreResponse)
async def create_genre(genre: GenreCreate, db=Depends(get_db)):
    res = await crud.create_genre(db, genre.model_dump())
    return res

@router.get("/", response_model=List[GenreResponse])
async def list_genres(db=Depends(get_db)):
    return await crud.get_genres(db)

@router.get("/{genre_id}", response_model=GenreResponse)
async def get_genre(genre_id: str, db=Depends(get_db)):
    res = await crud.get_genre(db, genre_id)
    if not res:
        raise HTTPException(status_code=404, detail="Genre not found")
    return res

@router.put("/{genre_id}", response_model=GenreResponse)
async def update_genre(genre_id: str, genre: GenreCreate, db=Depends(get_db)):
    res = await crud.update_genre(db, genre_id, genre.model_dump())
    if not res:
        raise HTTPException(status_code=404, detail="Genre not found")
    return res

@router.delete("/{genre_id}")
async def delete_genre(genre_id: str, db=Depends(get_db)):
    success = await crud.delete_genre(db, genre_id)
    if not success:
        raise HTTPException(status_code=404, detail="Genre not found or could not be deleted")
    return {"message": "Genre deleted successfully"}
