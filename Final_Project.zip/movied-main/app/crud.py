from bson import ObjectId
from datetime import datetime
from typing import List, Dict, Any, Optional

def serialize_doc(doc: Any) -> Any:
    if doc is None:
        return None
    if isinstance(doc, ObjectId):
        return str(doc)
    if isinstance(doc, list):
        return [serialize_doc(x) for x in doc]
    if isinstance(doc, dict):
        serialized = {}
        for k, v in doc.items():
            if k == "_id":
                serialized["id"] = str(v)
            elif isinstance(v, ObjectId):
                serialized[k] = str(v)
            elif isinstance(v, datetime):
                serialized[k] = v.isoformat()
            elif isinstance(v, (list, dict)):
                serialized[k] = serialize_doc(v)
            else:
                serialized[k] = v
        return serialized
    return doc

def serialize_docs(docs: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    return [serialize_doc(doc) for doc in docs]

# --- Directors CRUD ---
async def create_director(db, data: dict) -> dict:
    result = await db.directors.insert_one(data)
    doc = await db.directors.find_one({"_id": result.inserted_id})
    return serialize_doc(doc)

async def get_director(db, director_id: str) -> Optional[dict]:
    if not ObjectId.is_valid(director_id):
        return None
    doc = await db.directors.find_one({"_id": ObjectId(director_id)})
    return serialize_doc(doc)

async def get_directors(db) -> List[dict]:
    cursor = db.directors.find()
    docs = await cursor.to_list(length=1000)
    return serialize_docs(docs)

async def update_director(db, director_id: str, data: dict) -> Optional[dict]:
    if not ObjectId.is_valid(director_id):
        return None
    update_data = {k: v for k, v in data.items() if v is not None}
    await db.directors.update_one({"_id": ObjectId(director_id)}, {"$set": update_data})
    doc = await db.directors.find_one({"_id": ObjectId(director_id)})
    return serialize_doc(doc)

async def delete_director(db, director_id: str) -> bool:
    if not ObjectId.is_valid(director_id):
        return False
    # Remove references from movies (optional, but clean: set director_id to None or delete movie)
    # The requirement is One Director -> Many Movies. Let's just delete the director,
    # and update movies to remove director reference.
    result = await db.directors.delete_one({"_id": ObjectId(director_id)})
    if result.deleted_count > 0:
        await db.movies.update_many({"director_id": ObjectId(director_id)}, {"$unset": {"director_id": ""}})
        return True
    return False

# --- Genres CRUD ---
async def create_genre(db, data: dict) -> dict:
    result = await db.genres.insert_one(data)
    doc = await db.genres.find_one({"_id": result.inserted_id})
    return serialize_doc(doc)

async def get_genre(db, genre_id: str) -> Optional[dict]:
    if not ObjectId.is_valid(genre_id):
        return None
    doc = await db.genres.find_one({"_id": ObjectId(genre_id)})
    return serialize_doc(doc)

async def get_genres(db) -> List[dict]:
    cursor = db.genres.find()
    docs = await cursor.to_list(length=1000)
    return serialize_docs(docs)

async def update_genre(db, genre_id: str, data: dict) -> Optional[dict]:
    if not ObjectId.is_valid(genre_id):
        return None
    await db.genres.update_one({"_id": ObjectId(genre_id)}, {"$set": data})
    doc = await db.genres.find_one({"_id": ObjectId(genre_id)})
    return serialize_doc(doc)

async def delete_genre(db, genre_id: str) -> bool:
    if not ObjectId.is_valid(genre_id):
        return False
    result = await db.genres.delete_one({"_id": ObjectId(genre_id)})
    if result.deleted_count > 0:
        await db.movies.update_many({"genre_id": ObjectId(genre_id)}, {"$unset": {"genre_id": ""}})
        return True
    return False

# --- Actors CRUD ---
async def create_actor(db, data: dict) -> dict:
    result = await db.actors.insert_one(data)
    doc = await db.actors.find_one({"_id": result.inserted_id})
    return serialize_doc(doc)

async def get_actor(db, actor_id: str) -> Optional[dict]:
    if not ObjectId.is_valid(actor_id):
        return None
    doc = await db.actors.find_one({"_id": ObjectId(actor_id)})
    return serialize_doc(doc)

async def get_actors(db) -> List[dict]:
    cursor = db.actors.find()
    docs = await cursor.to_list(length=1000)
    return serialize_docs(docs)

async def update_actor(db, actor_id: str, data: dict) -> Optional[dict]:
    if not ObjectId.is_valid(actor_id):
        return None
    update_data = {k: v for k, v in data.items() if v is not None}
    await db.actors.update_one({"_id": ObjectId(actor_id)}, {"$set": update_data})
    doc = await db.actors.find_one({"_id": ObjectId(actor_id)})
    return serialize_doc(doc)

async def delete_actor(db, actor_id: str) -> bool:
    if not ObjectId.is_valid(actor_id):
        return False
    result = await db.actors.delete_one({"_id": ObjectId(actor_id)})
    if result.deleted_count > 0:
        # Pull actor_id from movies
        await db.movies.update_many({}, {"$pull": {"actor_ids": ObjectId(actor_id)}})
        return True
    return False

# --- Movies CRUD ---
async def create_movie(db, data: dict) -> dict:
    # Convert string IDs to ObjectIds for database reference integrity
    db_data = {
        "title": data["title"],
        "release_year": data["release_year"],
        "duration": data["duration"],
        "language": data["language"],
        "rating": data.get("rating", 0.0),
        "box_office": data.get("box_office", 0.0),
    }
    
    if data.get("director_id") and ObjectId.is_valid(data["director_id"]):
        db_data["director_id"] = ObjectId(data["director_id"])
    if data.get("genre_id") and ObjectId.is_valid(data["genre_id"]):
        db_data["genre_id"] = ObjectId(data["genre_id"])
    if data.get("actor_ids"):
        db_data["actor_ids"] = [ObjectId(aid) for aid in data["actor_ids"] if ObjectId.is_valid(aid)]
    else:
        db_data["actor_ids"] = []

    result = await db.movies.insert_one(db_data)
    doc = await db.movies.find_one({"_id": result.inserted_id})
    return serialize_doc(doc)

async def get_movie(db, movie_id: str) -> Optional[dict]:
    if not ObjectId.is_valid(movie_id):
        return None
    doc = await db.movies.find_one({"_id": ObjectId(movie_id)})
    return serialize_doc(doc)

async def get_movies(db) -> List[dict]:
    cursor = db.movies.find()
    docs = await cursor.to_list(length=1000)
    return serialize_docs(docs)

async def get_movie_detailed(db, movie_id: str) -> Optional[dict]:
    if not ObjectId.is_valid(movie_id):
        return None
    
    pipeline = [
        {"$match": {"_id": ObjectId(movie_id)}},
        {
            "$lookup": {
                "from": "directors",
                "localField": "director_id",
                "foreignField": "_id",
                "as": "director"
            }
        },
        {"$unwind": {"path": "$director", "preserveNullAndEmptyArrays": True}},
        {
            "$lookup": {
                "from": "genres",
                "localField": "genre_id",
                "foreignField": "_id",
                "as": "genre"
            }
        },
        {"$unwind": {"path": "$genre", "preserveNullAndEmptyArrays": True}},
        {
            "$lookup": {
                "from": "actors",
                "localField": "actor_ids",
                "foreignField": "_id",
                "as": "actors"
            }
        },
        {
            "$lookup": {
                "from": "reviews",
                "localField": "_id",
                "foreignField": "movie_id",
                "as": "reviews"
            }
        }
    ]
    cursor = db.movies.aggregate(pipeline)
    docs = await cursor.to_list(length=1)
    if docs:
        return serialize_doc(docs[0])
    return None

async def get_movies_detailed(db) -> List[dict]:
    pipeline = [
        {
            "$lookup": {
                "from": "directors",
                "localField": "director_id",
                "foreignField": "_id",
                "as": "director"
            }
        },
        {"$unwind": {"path": "$director", "preserveNullAndEmptyArrays": True}},
        {
            "$lookup": {
                "from": "genres",
                "localField": "genre_id",
                "foreignField": "_id",
                "as": "genre"
            }
        },
        {"$unwind": {"path": "$genre", "preserveNullAndEmptyArrays": True}},
        {
            "$lookup": {
                "from": "actors",
                "localField": "actor_ids",
                "foreignField": "_id",
                "as": "actors"
            }
        },
        {
            "$lookup": {
                "from": "reviews",
                "localField": "_id",
                "foreignField": "movie_id",
                "as": "reviews"
            }
        }
    ]
    cursor = db.movies.aggregate(pipeline)
    docs = await cursor.to_list(length=1000)
    return serialize_docs(docs)

async def update_movie(db, movie_id: str, data: dict) -> Optional[dict]:
    if not ObjectId.is_valid(movie_id):
        return None
        
    db_data = {}
    for k in ["title", "release_year", "duration", "language", "rating", "box_office"]:
        if k in data and data[k] is not None:
            db_data[k] = data[k]
            
    if "director_id" in data:
        db_data["director_id"] = ObjectId(data["director_id"]) if data["director_id"] and ObjectId.is_valid(data["director_id"]) else None
    if "genre_id" in data:
        db_data["genre_id"] = ObjectId(data["genre_id"]) if data["genre_id"] and ObjectId.is_valid(data["genre_id"]) else None
    if "actor_ids" in data:
        db_data["actor_ids"] = [ObjectId(aid) for aid in data["actor_ids"] if ObjectId.is_valid(aid)]
        
    await db.movies.update_one({"_id": ObjectId(movie_id)}, {"$set": db_data})
    doc = await db.movies.find_one({"_id": ObjectId(movie_id)})
    return serialize_doc(doc)

async def delete_movie(db, movie_id: str) -> bool:
    if not ObjectId.is_valid(movie_id):
        return False
    result = await db.movies.delete_one({"_id": ObjectId(movie_id)})
    if result.deleted_count > 0:
        # Clean up reviews associated with this movie
        await db.reviews.delete_many({"movie_id": ObjectId(movie_id)})
        return True
    return False

# --- Reviews CRUD ---
async def create_review(db, data: dict) -> dict:
    db_data = {
        "reviewer_name": data["reviewer_name"],
        "rating": data["rating"],
        "review_text": data["review_text"],
        "created_at": datetime.utcnow()
    }
    if data.get("movie_id") and ObjectId.is_valid(data["movie_id"]):
        db_data["movie_id"] = ObjectId(data["movie_id"])

    result = await db.reviews.insert_one(db_data)
    doc = await db.reviews.find_one({"_id": result.inserted_id})
    
    # Optional trigger: recalculate average rating for the movie when a review is added
    if "movie_id" in db_data:
        await recalculate_movie_rating(db, db_data["movie_id"])
        
    return serialize_doc(doc)

async def get_review(db, review_id: str) -> Optional[dict]:
    if not ObjectId.is_valid(review_id):
        return None
    doc = await db.reviews.find_one({"_id": ObjectId(review_id)})
    return serialize_doc(doc)

async def get_reviews(db) -> List[dict]:
    cursor = db.reviews.find()
    docs = await cursor.to_list(length=1000)
    return serialize_docs(docs)

async def update_review(db, review_id: str, data: dict) -> Optional[dict]:
    if not ObjectId.is_valid(review_id):
        return None
    update_data = {k: v for k, v in data.items() if v is not None}
    if "movie_id" in update_data and ObjectId.is_valid(update_data["movie_id"]):
        update_data["movie_id"] = ObjectId(update_data["movie_id"])
        
    await db.reviews.update_one({"_id": ObjectId(review_id)}, {"$set": update_data})
    doc = await db.reviews.find_one({"_id": ObjectId(review_id)})
    
    # Recalculate movie rating
    if doc and "movie_id" in doc:
        await recalculate_movie_rating(db, doc["movie_id"])
        
    return serialize_doc(doc)

async def delete_review(db, review_id: str) -> bool:
    if not ObjectId.is_valid(review_id):
        return False
    doc = await db.reviews.find_one({"_id": ObjectId(review_id)})
    result = await db.reviews.delete_one({"_id": ObjectId(review_id)})
    if result.deleted_count > 0:
        if doc and "movie_id" in doc:
            await recalculate_movie_rating(db, doc["movie_id"])
        return True
    return False

async def recalculate_movie_rating(db, movie_id: ObjectId):
    # Calculate average rating of all reviews for this movie
    pipeline = [
        {"$match": {"movie_id": movie_id}},
        {"$group": {"_id": "$movie_id", "avg_rating": {"$avg": "$rating"}}}
    ]
    cursor = db.reviews.aggregate(pipeline)
    result = await cursor.to_list(length=1)
    if result:
        avg_rating = round(result[0]["avg_rating"], 1)
        await db.movies.update_one({"_id": movie_id}, {"$set": {"rating": avg_rating}})
    else:
        # Default or reset to 0
        await db.movies.update_one({"_id": movie_id}, {"$set": {"rating": 0.0}})
