from contextlib import asynccontextmanager
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.database import db_instance
from app.routes import directors, genres, actors, movies, reviews, reports
import os

@asynccontextmanager
async def lifespan(app: FastAPI):
    # Connect to MongoDB on startup
    db_instance.connect()
    yield
    # Close MongoDB connection on shutdown
    db_instance.close()

app = FastAPI(
    title="Movie Database Management System API",
    description="A FastAPI backend and MongoDB aggregation engine for managing movies, actors, directors, genres, and reviews.",
    version="1.0.0",
    lifespan=lifespan
)

# Enable CORS for development
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Include API Routers
app.include_router(directors.router)
app.include_router(genres.router)
app.include_router(actors.router)
app.include_router(movies.router)
app.include_router(reviews.router)
app.include_router(reports.router)

# Roots status check
@app.get("/")
async def status_check():
    """Returns the backend API service status."""
    return {"status": "healthy", "description": "Movie Database API Backend is active (CLI-only mode)."}
