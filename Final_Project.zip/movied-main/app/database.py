from motor.motor_asyncio import AsyncIOMotorClient
from app.config import MONGO_URI, DB_NAME

class Database:
    def __init__(self):
        self.client = None
        self.db = None

    def connect(self):
        self.client = AsyncIOMotorClient(MONGO_URI)
        self.db = self.client[DB_NAME]

    def close(self):
        if self.client:
            self.client.close()

db_instance = Database()

def get_db():
    if db_instance.db is None:
        raise RuntimeError("Database not initialized")
    return db_instance.db
