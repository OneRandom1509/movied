from pydantic import BaseModel, Field
from typing import List, Optional
from datetime import datetime

# --- Genre ---
class GenreCreate(BaseModel):
    name: str

class GenreResponse(BaseModel):
    id: str
    name: str

# --- Director ---
class DirectorCreate(BaseModel):
    name: str
    birth_year: Optional[int] = None
    nationality: Optional[str] = None

class DirectorResponse(BaseModel):
    id: str
    name: str
    birth_year: Optional[int] = None
    nationality: Optional[str] = None

# --- Actor ---
class ActorCreate(BaseModel):
    name: str
    birth_year: Optional[int] = None
    nationality: Optional[str] = None

class ActorResponse(BaseModel):
    id: str
    name: str
    birth_year: Optional[int] = None
    nationality: Optional[str] = None

# --- Review ---
class ReviewCreate(BaseModel):
    movie_id: str
    reviewer_name: str
    rating: float
    review_text: str

class ReviewResponse(BaseModel):
    id: str
    movie_id: str
    reviewer_name: str
    rating: float
    review_text: str
    created_at: datetime

# --- Movie ---
class MovieCreate(BaseModel):
    title: str
    release_year: int
    duration: int  # in minutes
    language: str
    rating: Optional[float] = 0.0
    box_office: Optional[float] = 0.0  # in millions
    director_id: str
    genre_id: str
    actor_ids: List[str] = []

class MovieResponse(BaseModel):
    id: str
    title: str
    release_year: int
    duration: int
    language: str
    rating: float
    box_office: float
    director_id: str
    genre_id: str
    actor_ids: List[str]

# --- Nested / Detailed Movie Response ---
class MovieDetailResponse(BaseModel):
    id: str
    title: str
    release_year: int
    duration: int
    language: str
    rating: float
    box_office: float
    director: Optional[DirectorResponse] = None
    genre: Optional[GenreResponse] = None
    actors: List[ActorResponse] = []
    reviews: List[ReviewResponse] = []
